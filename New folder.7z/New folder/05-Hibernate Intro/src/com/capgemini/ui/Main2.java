package com.capgemini.ui;
import java.util.List;

import javax.management.Query;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Employee;

public class Main2 {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em= emf.createEntityManager();
		String myQuery="from Employee";
		javax.persistence.Query query=em.createQuery(myQuery); 
		List<Employee> empList=null;
		//to display all rows
		empList=query.getResultList();
		System.out.println(empList);
		em.close();
		emf.close();
		
	}

}
