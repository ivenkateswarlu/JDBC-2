package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main5 {

	public static void main(String[] args) {
		Contact contact1=new Contact(1400, "Vamsi", "8686586905");
		Contact contact2=new Contact(1401, "Akhil", "8886171715");
		Contact contact3=new Contact(1402, "sai",  "9999999999");
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em= emf.createEntityManager();
		//EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		//EntityManagerem=emf.createEntityManager();
		
		//em.getTransaction().begin();
	//	em.persist(contact1);
	//	em.persist(contact2);
	//	em.persist(contact3);
	//em.getTransaction().commit();
		/*contact3.setPhoneNumber("9949434544");
		em.merge(contact3);
		
		emf=Persistence.createEntityManagerFactory("JPA-PU");
		em=emf.createEntityManager();*/
		Contact contact4=null;
		contact4=em.find(Contact.class, 1400);
		contact4.setPhoneNumber("123456789");
		em.merge(contact4);
		System.out.println("  "+contact4.equals(contact1));
		//em.close();
		//emf.close();
		
	}

}
