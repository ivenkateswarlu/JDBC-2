package com.training.client;
/**
@author venimmad
*/
public class Test4 {
	/**
	 @param n-number to be completed for square
	 @return return  square of that number
	 */
int square(int n){
	return n*n;
}
}
