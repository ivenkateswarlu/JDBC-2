package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

//import com.capgemini.business.Employee;

public class Main {

	public static void main(String[] args) {
		
	Student student=null;

	EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
	EntityManager em = factory.createEntityManager();
	
	
	student=em.find(Student.class, 1);
	em.getTransaction().begin();
	//deleted
	em.remove(student);
	em.getTransaction().commit();
	em.close();
	factory.close();

	}

}
