package com.cg.jpastart.entities;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

//import com.capgemini.business.Employee;

public class Main1 {

	public static void main(String[] args) {
		Student student=null;

		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		String myQuery="from Student";
		em.getTransaction().begin();
		Query query=em.createQuery(myQuery);
		List<Student> studentList=null;
		//to display all rows
		studentList=query.getResultList();
		for (Student student2 : studentList) {
			student2.getName().toUpperCase();
			em.merge(student2);
			
			
		}
		em.getTransaction().clo
		//System.out.println(studentList);
		

	}

}
