package com.cg.jpastart.entities;

import javax.annotation.Generated;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity// table should be created
public class Trip {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	int trip_Id;
	public int getTrip_Id() {
	return trip_Id;
}
public void setTrip_Id(int trip_Id) {
	this.trip_Id = trip_Id;
}
public String getFromCity() {
	return fromCity;
}
public void setFromCity(String fromCity) {
	this.fromCity = fromCity;
}
public String getToCity() {
	return toCity;
}
public void setToCity(String toCity) {
	this.toCity = toCity;
}
public SeatInfo getInfo() {
	return info;
}
@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((fromCity == null) ? 0 : fromCity.hashCode());
	result = prime * result + ((info == null) ? 0 : info.hashCode());
	result = prime * result + ((toCity == null) ? 0 : toCity.hashCode());
	result = prime * result + trip_Id;
	return result;
}
@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Trip other = (Trip) obj;
	if (fromCity == null) {
		if (other.fromCity != null)
			return false;
	} else if (!fromCity.equals(other.fromCity))
		return false;
	if (info == null) {
		if (other.info != null)
			return false;
	} else if (!info.equals(other.info))
		return false;
	if (toCity == null) {
		if (other.toCity != null)
			return false;
	} else if (!toCity.equals(other.toCity))
		return false;
	if (trip_Id != other.trip_Id)
		return false;
	return true;
}
public void setInfo(SeatInfo info) {
	this.info = info;
}
	String fromCity;
	String toCity;
	@Embedded
	SeatInfo info;
	@Override
	public String toString() {
		return "Trip [trip_Id=" + trip_Id + ", fromCity=" + fromCity
				+ ", toCity=" + toCity + ", info=" + info + "]";
	}
	
	
}
